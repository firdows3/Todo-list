
const initialState = {
    tasks: []
};

export default function todoListReducer (state = initialState, action){
    switch (action.type) {
        case 'ADD_TODO':
            return{
                ...state,
                tasks: [...state.tasks, action.payload]
            };

        case 'REMOVE_TODO':
            return {
                ...state,
                tasks: state.tasks.filter(task => task.id != action.payload)
            };

        case 'UPDATE_TODO': 
        console.log(action.payload);
            const updatedTaskIndex = state.tasks.findIndex(task => task.id === action.payload)

            if(updatedTaskIndex !== -1){
                const updatedTasks = [...state.tasks];
                updatedTasks[updatedTaskIndex] = action.payload;
                return {
                    ...state,
                    tasks: updatedTasks
                }
            }
            return state;
        
            default:
                return state;
    }
}