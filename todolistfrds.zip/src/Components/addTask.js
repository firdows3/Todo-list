import { connect } from "react-redux";
import { useEffect, useState } from "react";
import { addTodo, removeTodo, updateTodo } from "../redux/todoList/todoListActions"
import { useNavigate } from "react-router";

function AddTask(props){

    const [task, setTask] = useState('')
    const [title, setTitle] = useState('')
    const navigation = useNavigate();

    useEffect(()=>{
      console.log();
    })

    const pushTask = () => {
        // push the new task to the tasks array
        // setTasks([{id: Math.floor(Math.random() * 20), task: task, isEditing: false, category: 'Pending'}, ...tasks])
        const newTask = ({
          id: Math.floor(Math.random() * 1000), // You may use a more reliable ID generation method
          title: title,
          task: task,
          category: 'Pending'
        });
        setTask('');

        props.addTodo(newTask)
    }

    return (
        <>
        <div className='todo-list-body'>
            <input className="todolist-title-input" placeholder='Add a title' value={title} onChange={(e) => setTitle(e.target.value)} />
            <textarea className="todolist-description-input" placeholder="Add a description" value={task} onChange={(e) => setTask(e.target.value)} />
            <div className="todolist-add-task-button" onClick={()=>{ 
              pushTask()
              navigation(-1)
              }}>Add</div>
        </div>
        </>
    )
}

function mapStateToProps (state) {
    return {
      tasks: state.todo.tasks
    }
  }
  
  function mapDispatchToProps (dispatch) {
    return {
      addTodo: (todo) => dispatch(addTodo(todo)),
      removeTodo: (id) => dispatch(removeTodo(id)),
      updateTodo: (todo) => dispatch(updateTodo(todo))
    };
  }
  
  export default connect(mapStateToProps, mapDispatchToProps)(AddTask)