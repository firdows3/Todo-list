import add from "./images/add.png"
import { Link } from "react-router-dom";
import { connect } from "react-redux";

function Footer(props){

    return(
        <div className='todo-list-footer'>
            <div>{props.tasks.length} Tasks</div>
            <Link to='addTodoList' className="todo-list-footer-right">
                <div>add task</div>
                <img className='todo-list-icon' src={add} />
            </Link>
        </div>
    )
}

function mapStateToProps (state) {
    return {
      tasks: state.todo.tasks
    }
  }
  export default connect(mapStateToProps)(Footer)