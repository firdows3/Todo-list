import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import './ToDoList.css'
import EachTask from './EachTask';
import { Outlet } from 'react-router';
import { addTodo, removeTodo, updateTodo } from '../redux/todoList/todoListActions';

function TodoList (props) {

  const [tasks, setTasks] = useState([])

  useEffect(() => {
    setTasks(props.tasks)
    console.log( tasks, props.tasks);
  }, [props])

    const handleDelete = (id) => {
      props.removeTodo(id);
  }

    // displaying date 
    return (
      <>
      <div className='todo-list-body-container'>
        {
          // displaying the tasks based on their category
          tasks.length === 0 ? <div className='todo-list-body-empty'> Have a good day ... &#x1F31E; </div> : 
          <div className='todo-list-body'>
               {
                  tasks.map(item => {
                      return <EachTask key={item.id} item={item} handleDelete={handleDelete}/>
                  })
               }
          </div>
        }
        <Outlet />
      </div>
      </>
    )
}

function mapStateToProps (state) {
  return {
    tasks: state.todo.tasks
  }
}
function mapDispatchToProps (dispatch) {
  return {
    addTodo: (todo) => dispatch(addTodo(todo)),
    removeTodo: (id) => dispatch(removeTodo(id)),
    updateTodo: (todo) => dispatch(updateTodo(todo))
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(TodoList)

    
    // const [filteredTasks, setFilteredTasks] = useState([]);

    // const filterCategories = (category) => {
    //     // filter categories based on the item's category
    //     const newCategory = tasks.filter(eachCategory => eachCategory.category === category);
    //     if (category === 'All'){
    //       return setFilteredTasks(tasks);
    //     }
    //     else{
    //       return setFilteredTasks(newCategory)
    //     }
    //   }



      // const handleEdit = () => {       
  //   updateTask({
  //       // this is the task to be edited
  //     ...item,
  //     task: editedText,
  //     isEditing: false,
  //     category: 'Pending'
  //   });
  // };


  // delete a task
      // const temp = [...tasks];
      // const i = temp.findIndex(item => item.id === id);
      // if (i < 0) return;
      // temp.splice(i, 1);
      // setTasks(temp);

  // update a task
  // const updatedTasks = tasks.map((task) =>
    // // ensuring weather the cuurent task is the task to be edited or not
    // task.id === updatedTask.id ? updatedTask : task
    // );
    // setTasks(updatedTasks);



   {/* <div className='todo-list-navbar'>
                {
                    // displaying the categories
                categories.map((item, index) => {
                  return <div className={activeCategory === index ? "each-todo-list-navbar active-category" : "each-todo-list-navbar"} 
                  onClick={()=>{
                    // filterCategories(item);
                    setActiveCategory(index);
                  }}>
                    {item}
                  </div>
                })
              }
            </div> */}