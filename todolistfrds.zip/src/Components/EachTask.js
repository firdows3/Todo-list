import { useState, useEffect } from "react";
import selectIcon from "./images/select.png"
import selected from "./images/selected.png"
import deleteIcon from "./images/delete.png"
import { Link } from "react-router-dom";

export default function EachTask ({ item, handleDelete }) {
    
    const [editedText, setEditedText] = useState(item.title);

    useEffect(()=>{
        setEditedText(item.title)
    }, [item])

      const [select, setSelect] =useState(false)
  
    return (
        <>
        <div className='todo-list-each-component'>
            <div className='todo-list-body-left'>
                <img src={select ? selected : selectIcon} className='todo-list-icon' 
                onClick={() => setSelect(true)} />
               <Link to={`${item.id}`}><div className={select ? 'todo-list-complited-task' : ''}>{editedText}</div></Link>
            </div>
            <div className='todo-list-edit-delete-icon'>
                <img src={deleteIcon} className='todo-list-icon' onClick={()=>handleDelete(item.id)} />
            </div>
        </div>
        </>
    )
}