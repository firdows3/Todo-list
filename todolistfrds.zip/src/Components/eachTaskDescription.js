import { useEffect, useState } from "react";
import { connect } from "react-redux";
import { useParams } from "react-router";
import edit from "./images/edit.webp" 
import { addTodo, updateTodo, removeTodo } from "../redux/todoList/todoListActions";

function EachTaskDescription(props){

    const [isEditingTitle, setIsEditingTitle] = useState(false)
    const [isEditingTask, setIsEditingTask] = useState(false)
    
    const updateTask = (updatedTask) => {
      console.log(updatedTask);
      props.updateTodo(updatedTask)
    };
    
    const { id } = useParams()
    // console.log(props.tasks);
    
    const eachTaskDescription = props.tasks.filter(taskDescription =>  taskDescription.id == id)
    const [editedDescription, setEditedDescription] = useState('tasks...')
    const [editedTitle, setEditedTitle] = useState('title')

    if(eachTaskDescription[0].length > 0){
       setEditedDescription(eachTaskDescription[0].task)
       setEditedTitle(eachTaskDescription[0].title)
    }

    useEffect(()=>{
      setEditedDescription(eachTaskDescription[0].task)
      setEditedTitle(eachTaskDescription[0].title)
      console.log(editedDescription);
    }, [eachTaskDescription[0]])

    return(
        <>
        <div className="todolist-each-component-container">
        {isEditingTitle ? (
        <div className='todo-list-edit'>
          <input
            type="text"
            value={editedTitle}
            onChange={(e) => setEditedTitle(e.target.value)}
            className='todo-list-edit-input'
          />
          <button className='todo-list-edit-button' 
          onClick={() => {
            updateTask(editedDescription);
            setIsEditingTitle(false)
          }}>Save</button>
        </div>
        ) : <div></div>}
        <div className="todolist-each-row">
          <div className="todolist-each-component-title">{editedTitle}</div>
          <img src={edit} className='todo-list-icon' onClick={() => setIsEditingTitle(true)} />
        </div>

        {isEditingTask ? (
        <div className='todo-list-edit'>
          <input
            type="text"
            value={editedDescription}
            onChange={(e) => setEditedDescription(e.target.value)}
            className='todo-list-edit-input'
          />
          <button className='todo-list-edit-button' 
          onClick={() => {
            updateTask(editedDescription);
            setIsEditingTask(false)
          }}>Save</button>
        </div>
        ) : <div></div>}
        <div className="todolist-each-row">
          <div className="todolist-each-component-description">{editedDescription}</div>
          <img src={edit} className='todo-list-icon' onClick={() => setIsEditingTask(true)} />
        </div>
        </div>
        </>
    )
}

function mapStateToProps (state) {
  return {
    tasks: state.todo.tasks
  }
}
function mapDispatchToProps (dispatch) {
  return {
    addTodo: (todo) => dispatch(addTodo(todo)),
    removeTodo: (id) => dispatch(removeTodo(id)),
    updateTodo: (todo) => dispatch(updateTodo(todo))
  };
}
export default connect(mapStateToProps, mapDispatchToProps)(EachTaskDescription)