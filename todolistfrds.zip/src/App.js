import { useState, useEffect } from "react";
import TodoList from "./Components/ToDoList";
import { Provider, connect } from "react-redux";
import store from "./redux/todoList/todoListState";
import { Link, Outlet, Route, Routes } from "react-router-dom";
import Header from "./Components/header";
import EachTaskDescription from "./Components/eachTaskDescription";
import Footer from "./Components/footer";
import AddTask from "./Components/addTask";

export default function App() {

  return (
    <Provider store={store} >
      <div className="App">
      <div className='todo-list-container'>
          <Header />
          <Routes>
            <Route path="/" element={<TodoList />}>
              <Route path=":id" element={<EachTaskDescription/>} />
            </Route>
            <Route path="addTodoList" element={<AddTask />} />
          </Routes>
          <Footer />
      </div> 
      </div>
    </Provider>
  );
}